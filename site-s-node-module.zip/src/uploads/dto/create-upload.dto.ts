export class CreateUploadDto {}
