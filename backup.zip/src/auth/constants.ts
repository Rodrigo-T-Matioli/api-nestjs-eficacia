export const jwtConstants = {
  secret: 'apiEficaciaContabil',
};
